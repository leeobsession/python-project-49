#!/usr/bin/env python3
from brain_games.games import logic_gcd


def main():
    logic_gcd()


if __name__ == '__main__':

    main()

# end
