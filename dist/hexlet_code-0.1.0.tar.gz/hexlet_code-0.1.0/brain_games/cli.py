
def welcom_user(name):

    return print(f"Hello, {name}!")
