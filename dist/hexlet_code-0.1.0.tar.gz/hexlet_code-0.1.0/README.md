### Hexlet tests and linter status:
[![Actions Status](https://github.com/leeobsession/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leeobsession/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b4c90daf2fdab1160cc6/maintainability)](https://codeclimate.com/github/leeobsession/python-project-49/maintainability)

This project includes five mini-games::

brain-even: Determine if the number is even
brain-calc: Calculate the mathematical expression
brain-progression: Define number is missing in the progression.
brain-gcd: Find the greatest common divisor of given numbers.
brain-prime: Find number is prime or no.

<a href="https://asciinema.org/a/8COUllwb1LBhnqshD5K6EMPNM" target="_blank"><img src="https://asciinema.org/a/8COUllwb1LBhnqshD5K6EMPNM.svg" /></a>


<a href="https://asciinema.org/a/rpeqySLxpZt0rVCrUzXI9fVOM" target="_blank"><img src="https://asciinema.org/a/rpeqySLxpZt0rVCrUzXI9fVOM.svg" /></a>

<a href="https://asciinema.org/a/CHpShTrtD2904J3aUtXDCgzUA" target="_blank"><img src="https://asciinema.org/a/CHpShTrtD2904J3aUtXDCgzUA.svg" /></a>

<a href="https://asciinema.org/a/lhuDWDkpJL1rs3oVDmU9RaGQB" target="_blank"><img src="https://asciinema.org/a/lhuDWDkpJL1rs3oVDmU9RaGQB.svg" /></a>

<a href="https://asciinema.org/a/amUUcfhVZAo7DziMsqHNsT1Jn" target="_blank"><img src="https://asciinema.org/a/amUUcfhVZAo7DziMsqHNsT1Jn.svg" /></a>