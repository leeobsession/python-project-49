### Hexlet tests and linter status:
[![Actions Status](https://github.com/leeobsession/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/leeobsession/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b4c90daf2fdab1160cc6/maintainability)](https://codeclimate.com/github/leeobsession/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/8COUllwb1LBhnqshD5K6EMPNM.svg)](https://asciinema.org/a/8COUllwb1LBhnqshD5K6EMPNM)


[![asciicast](https://asciinema.org/a/rpeqySLxpZt0rVCrUzXI9fVOM.svg)](https://asciinema.org/a/rpeqySLxpZt0rVCrUzXI9fVOM)

[![asciicast](https://asciinema.org/a/CHpShTrtD2904J3aUtXDCgzUA.svg)](https://asciinema.org/a/CHpShTrtD2904J3aUtXDCgzUA)